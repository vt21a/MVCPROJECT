using Microsoft.EntityFrameworkCore;
using DigitalArtGallery.Entity;
using DigitalStudentArtGallery.Entity;
using System.Collections.Generic;
using DigitalStudentArtGallery.Entity;
using DigitalStudentArtGallery.Models;

namespace DigitalArtGallery.Data
{
    public class ApplicationDbContext : DbContext
    {
        private DbContextOptions<ApplicationDbContext> _options;
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) {
            _options = options;
        }

        public DbSet<AppUser> Users { get; set; }

        public DbSet<Artpiece> ArtPieces { get; set; }
        public DbSet<Artist> Artists { get; set; }
        public DbSet<Gallery> Galleries { get; set; }
        public DbSet<Post> Posts { get; set; }


    }
}

