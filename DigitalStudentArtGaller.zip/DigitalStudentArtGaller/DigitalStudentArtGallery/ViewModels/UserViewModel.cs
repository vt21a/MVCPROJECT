﻿
namespace DigitalArtGallery.ViewModel
{
    public class UserViewModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Email { get; set; } // For registration only

        internal void AddModelError(string v1, string v2)
        {
            throw new NotImplementedException();
        }
    }
}


