﻿namespace DigitalArtGallery.ViewModel
{
    public class ArtPieceViewModel
    {
        public string Title { get; set; }
        public string ImagePath { get; set; }
        public string ArtistName { get; set; }
    }
}

