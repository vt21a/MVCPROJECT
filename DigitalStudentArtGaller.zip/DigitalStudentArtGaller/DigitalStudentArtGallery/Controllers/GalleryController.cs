﻿using DigitalArtGallery.Repository;
using DigitalArtGallery.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Linq;

namespace DigitalArtGallery.Controller
{
    [Authorize]
    public class GalleryController
    {
        private readonly ArtPieceRepository _artPieceRepo;
        private readonly GalleryRepository _galleryRepo;

        public GalleryController(ArtPieceRepository artPieceRepo, GalleryRepository galleryRepo)
        {
            _artPieceRepo = artPieceRepo;
            _galleryRepo = galleryRepo;
        }

        public IActionResult Details(int galleryId)
        {
            
            var gallery = _galleryRepo.GetGalleryById(galleryId);

            var galleryViewModel = new GalleryViewModel
            {
                GalleryId = gallery.Id,
                Name = gallery.Name,
                ArtPieces = gallery.ArtPieces.Select(a => new ArtPieceViewModel
                {
                    Title = a.Title,
                    ImagePath = a.ImagePath,
                    ArtistName = a.Artist.Name
                }).ToList()
            };
            
            if (gallery == null)
            {
                return NotFound();
            }
           return View(galleryViewModel);
        }

        private IActionResult View(GalleryViewModel galleryViewModel)
        {
            throw new NotImplementedException();
        }

        private IActionResult NotFound()
        {
            throw new NotImplementedException();
        }
    }
}
