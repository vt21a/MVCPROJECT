using Microsoft.AspNetCore.Mvc;
using DigitalStudentArtGallery.Models;
using DigitalStudentArtGallery.Helpers;
using Microsoft.EntityFrameworkCore;
//using DigitalStudentArtGallery.Data;
using DigitalArtGallery.Data;

namespace DigitalStudentArtGallery.Controllers
{
    public class RegisterController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RegisterController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index() => View();

        [HttpPost]
        public async Task<IActionResult> Index(string username, string email, string password)
        {
            if (_context.Users.Any(u => u.Username == username))
            {
                ModelState.AddModelError("", "Username already exists.");
                return View();
            }

            var user = new AppUser
            {
                Username = username,
                Email = email,
                PasswordHash = PasswordHelper.HashPassword(password)
            };

            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index", "Login");
        }
    }
}
