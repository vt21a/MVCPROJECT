﻿using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using DigitalArtGallery.Data; // Ensure this namespace is correct for your DbContext
using DigitalStudentArtGallery.Models; // Ensure this namespace is correct for your AppUser model
using DigitalStudentArtGallery.Helpers; // Ensure this namespace is correct for your PasswordHelper

namespace DigitalStudentArtGallery.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(string username, string password)
        {
            // Find the user by username in the database
            var user = _context.Users.FirstOrDefault(u => u.Username == username);

            // Verify if the user exists and the password is correct using your helper
            if (user != null && PasswordHelper.VerifyPassword(password, user.PasswordHash))
            {
                // Create claims for the authenticated user
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, username), // The primary identity of the user
                    new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()), // Store user ID
                    new Claim(ClaimTypes.Email, user.Email) // Store user email as a claim
                    // Add any other claims you need for roles, etc.
                };

                // Create a ClaimsIdentity with the specified authentication scheme ("Cookies")
                var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var principal = new ClaimsPrincipal(identity);

                // Sign in the user
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

                // Redirect to the Posts Index page after successful login
                return RedirectToAction("Index", "Posts");
            }

            // If login fails, set an error message in ViewBag and return the view
            ViewBag.Error = "Invalid username or password.";
            return View();
        }


        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost] // Corrected: Removed duplicate [HttpPost] attribute
        public IActionResult Register(string username, string password, string email)
        {
            // Hash the provided password using your helper
            var hashedPassword = PasswordHelper.HashPassword(password);

            // Check if the username already exists in the database
            if (_context.Users.Any(u => u.Username == username))
            {
                ViewBag.Error = "Username already taken.";
                return View(); // Return to the registration view with an error
            }

            // Create a new AppUser object
            var newUser = new AppUser
            {
                Username = username,
                PasswordHash = hashedPassword, // Store the hashed password
                Email = email
            };

            // Add the new user to the database and save changes
            _context.Users.Add(newUser);
            _context.SaveChanges();

            // Redirect to the Login page after successful registration
            TempData["SuccessMessage"] = "Registration successful! Please login."; // Added a success message
            return RedirectToAction("Login");
        }


        [HttpPost]
        [ValidateAntiForgeryToken] // Good practice for POST actions that modify state
        public async Task<IActionResult> Logout()
        {
            // Sign out the current user from the "Cookies" authentication scheme
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            // Redirect to the Login page after logout
            TempData["SuccessMessage"] = "You have been logged out successfully."; // Added a success message
            return RedirectToAction("Login");
        }


        [HttpGet]
         // Restrict access to authenticated users only
        public IActionResult Index()
        {
            // This action will display the account details for the currently logged-in user.
            // If the user is not authenticated, the [Authorize] attribute will redirect them to the LoginPath.
            return View();
        }

        // Action for Access Denied page (configured in Program.cs)
        public IActionResult AccessDenied()
        {
            return View(); // Return a view for access denied. You might want to create AccessDenied.cshtml
        }

        // Example: If you uncommented PurchaseHistory previously and it needs ApplicationDbContext
        /*
        [Authorize] // Ensure only authorized users can view purchase history
        public async Task<IActionResult> PurchaseHistory()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier); // Get the user ID from claims
            // Example: Fetch purchases from your DbContext
            // var purchases = await _context.RentalPurchases
            //     .Where(p => p.UserId == userId)
            //     .OrderByDescending(p => p.PurchaseDate)
            //     .ToListAsync();
            // return View(purchases);

            // Placeholder if not fully implemented
            return View();
        }
        */
    }
}