﻿using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using DigitalArtGallery.Data;
using DigitalStudentArtGallery.Models;
using DigitalStudentArtGallery.Helpers;

namespace DigitalStudentArtGallery.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(string username, string password)
        {
            var user = _context.Users.FirstOrDefault(u => u.Username == username);
            if (user != null && PasswordHelper.VerifyPassword(password, user.PasswordHash))
            {
                var claims = new List<Claim>
        {
            new Claim(ClaimTypes.Name, username)
        };

                var identity = new ClaimsIdentity(claims, "Cookies");
                var principal = new ClaimsPrincipal(identity);
                await HttpContext.SignInAsync("Cookies", principal);

                return RedirectToAction("Index", "Posts");
            }

            ViewBag.Error = "Invalid username or password.";
            return View();
        }


        [HttpGet]
        public IActionResult Register() => View();

        [HttpPost]
        [HttpPost]
        public IActionResult Register(string username, string password, string email)
        {
            //start

            var hashedPassword = PasswordHelper.HashPassword(password);

            if (_context.Users.Any(u => u.Username == username))
            {
                ViewBag.Error = "Username already taken.";
                return View();
            }

            var newUser = new AppUser
            {
                Username = username,
                //Password = password,
                PasswordHash = hashedPassword,
                Email = email
            };

            _context.Users.Add(newUser);
            _context.SaveChanges();

            return RedirectToAction("Login");
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync("Cookies");
            return RedirectToAction("Login");
        }




        public IActionResult AccessDenied()
        {
            return Content("Access denied.");
        }

    }
}
