using DigitalArtGallery.Entity;
using DigitalArtGallery.Repository;
using DigitalArtGallery.ViewModel;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace DigitalArtGallery.Controller
{
    public class AuthController : ArtistRepository
    {
        private readonly UserRepository _userRepository;

        public object ModelState { get; private set; }

        public AuthController(UserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        // Register action
        [HttpPost]
        public IActionResult Register(UserViewModel model)
        {
            if (model == null)
            {
                //create the user with the password
                var user = new User
                {
                    Username = model.Username,
                    Email = model.Email,
                    PasswordHash = model.Password // Storing password 
                };


                return RedirectToAction("Login", "Home");
            }

            return View(model);
        }

        private IActionResult View(UserViewModel model)
        {
            throw new NotImplementedException();
        }

        // Login action
        [HttpPost]
        public IActionResult Login(UserViewModel model)
        {
            if (model != null)
            {
                // Retrieve the user by username
                var user = _userRepository.GetUserByUsernameAsync(model.Username).Result;
                // Check if the password matches 
                if (user != null && model.Password == user.PasswordHash)
                {
                    return RedirectToAction("Index", "Home");
                }

                model.AddModelError("", "Invalid username or password.");
            }

            return View(model);
        }

        private IActionResult RedirectToAction(string v1, string v2)
        {
            throw new NotImplementedException();
        }
    }
}

