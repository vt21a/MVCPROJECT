﻿using DigitalArtGallery.Repository;
using DigitalArtGallery.ViewModel;
using Microsoft.AspNetCore.Authorization;
using System.Collections.Generic;

namespace DigitalArtGallery.Controller
{
    [Authorize]
    public class ArtPieceController
    {
        private ArtPieceRepository _artPieceRepo;

        public ArtPieceController()
        {
            _artPieceRepo = new ArtPieceRepository();
        }

        public List<ArtPieceViewModel> GetAllArtPieces()
        {
            var artPieces = _artPieceRepo.GetAllArtPieces();
            var viewModels = new List<ArtPieceViewModel>();

            foreach (var artPiece in artPieces)
            {
                viewModels.Add(new ArtPieceViewModel
                {
                    Title = artPiece.Title,
                    ImagePath = artPiece.ImagePath,
                    ArtistName = artPiece.Artist.Name
                });
            }

            return viewModels;
        }
    }
}

