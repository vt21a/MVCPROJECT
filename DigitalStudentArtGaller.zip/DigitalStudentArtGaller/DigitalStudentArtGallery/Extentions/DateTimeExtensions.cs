﻿namespace DigitalArtGallery.Extensions
{
    public static class DateTimeExtensions
    {
        public static string ToShortDate(this DateTime date)
        {
            return date.ToString("yyyy-MM-dd");
        }
    }
}

