﻿namespace DigitalArtGallery.Filters
{
    public class ArtPieceFilter
    {
        public string Title { get; set; }
        public string ArtistName { get; set; }
        public DateTime? DateCreated { get; set; }

    }
}

