﻿using DigitalArtGallery.Entity;
using DigitalStudentArtGallery.Entity;
using System.Collections.Generic;
using System.Linq;

namespace DigitalArtGallery.Repository
{
    public class ArtistRepository
    {
        private List<Artist> _artists;

        public ArtistRepository()
        {
            _artists = new List<Artist>(); // Ideally fetched from database
        }

        public List<Artist> GetAllArtists()
        {
            return _artists;
        }

        public Artist GetArtistById(int id)
        {
            return _artists.FirstOrDefault(a => a.Id == id);
        }
    }
}

