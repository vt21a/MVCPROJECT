﻿using DigitalArtGallery.Entity;
using DigitalStudentArtGallery.Entity;
using System.Collections.Generic;
using System.Linq;

namespace DigitalArtGallery.Repository
{
    public class ArtPieceRepository
    {
        private List<Artpiece> _artPieces;

        public ArtPieceRepository()
        {
            _artPieces = new List<Artpiece>(); //  from database
        }

        public List<Artpiece> GetAllArtPieces()
        {
            return _artPieces;
        }

        public Artpiece GetArtPieceById(int id)
        {
            return _artPieces.FirstOrDefault(a => a.Id == id);
        }

        public void AddArtPiece(Artpiece artPiece)
        {
            _artPieces.Add(artPiece);
        }
    }
}

