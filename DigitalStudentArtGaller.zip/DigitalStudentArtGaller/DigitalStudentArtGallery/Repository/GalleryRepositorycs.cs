﻿using DigitalArtGallery.Entity;
using System.Collections.Generic;
using System.Linq;

namespace DigitalArtGallery.Repository
{
    public class GalleryRepository
    {
        private List<Gallery> _galleries;

        public GalleryRepository()
        {
            _galleries = new List<Gallery>(); // from the database
        }

        public Gallery GetGalleryById(int id)
        {
            return _galleries.FirstOrDefault(g => g.Id == id);
        }

        public List<Gallery> GetAllGalleries()
        {
            return _galleries;
        }
    }
}

