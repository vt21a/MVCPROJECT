using Microsoft.EntityFrameworkCore;
using DigitalArtGallery.Repository; // Assuming this is needed elsewhere in your app
using DigitalArtGallery.Data;
using Microsoft.AspNetCore.Authentication.Cookies; // Make sure this is included

var builder = WebApplication.CreateBuilder(args);

// Register DbContext with connection string from appsettings.json
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// MVC, Views, Sessions
builder.Services.AddControllersWithViews();
builder.Services.AddSession();

// Configure custom Cookie Authentication
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/AccessDenied";
        options.Cookie.Name = "YourAppNameCookie"; // Optional: Give your cookie a specific name
        options.ExpireTimeSpan = TimeSpan.FromMinutes(30); // Optional: Set cookie expiration
        options.SlidingExpiration = true; // Optional: Renew cookie on activity
    });

builder.Services.AddAuthorization(); // Required for [Authorize] attribute

var app = builder.Build();

// Use error handling for production
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseSession(); // UseSession before UseAuthentication/UseAuthorization

// Order is important for authentication middleware
app.UseAuthentication();
app.UseAuthorization();


// Default route � change Posts to Home if needed
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Posts}/{action=Index}/{id?}"); // Keeping "Posts" as default as per your initial Program.cs

app.Run();