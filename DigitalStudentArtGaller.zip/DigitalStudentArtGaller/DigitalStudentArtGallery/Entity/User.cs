﻿namespace DigitalArtGallery.Entity
{
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
        public string PasswordHash { get; set; }  // Store hashed password
        public string Email { get; set; }
        public bool IsAdmin { get; set; }  // Optional: to distinguish between regular users and admins
    }
}

