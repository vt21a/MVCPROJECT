﻿using DigitalStudentArtGallery.Entity;

namespace DigitalArtGallery.Entity
{
    public class Gallery
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public List<Artpiece> ArtPieces { get; set; }
    }
}

