﻿namespace DigitalStudentArtGallery.Entity
{
    public class Artpiece
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string ImagePath { get; set; }
        public DateTime CreatedAt { get; set; }
        public int ArtistId { get; set; }
        public Artist Artist { get; set; }
    }
}
