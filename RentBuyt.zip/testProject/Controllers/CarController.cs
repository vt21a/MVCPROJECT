﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using testProject.Models;

namespace testProject.Controllers
{
    public class CarController : Controller
    {
        // ✅ Shared car list for consistent data
        private static readonly List<Car> cars = new List<Car>
        {
            new Car
            {
                Id = 1,
                Brand = "Toyota",
                Model = "Corolla",
                ImageUrl = "https://scene7.toyota.eu/is/image/toyotaeurope/COR0004b_25_WEB_crop:Large-Landscape?ts=0&resMode=sharp2&op_usm=1.75,0.3,2,0&fmt=png-alpha",
                RentalPricePerDay = 50,
                PurchasePrice = 15000,
                IsForRent = true,
                IsForSale = true
            },
            new Car
            {
                Id = 2,
                Brand = "BMW",
                Model = "X5",
                ImageUrl = "https://7cars.bg/wp-content/uploads/2024/09/1-2.jpg",
                RentalPricePerDay = 110,
                PurchasePrice = 45000,
                IsForRent = true,
                IsForSale = false
            },
            new Car
            {
                Id = 3,
                Brand = "Ferrari",
                Model = "SF90",
                ImageUrl = "https://hips.hearstapps.com/hmg-prod/images/2024-ferrari-sf90-xx-stradale-109-654a668fc71a3.jpg?crop=0.582xw:0.490xh;0.204xw,0.373xh&resize=1200:*",
                RentalPricePerDay = 390,
                PurchasePrice = 950000,
                IsForRent = true,
                IsForSale = false
            },
            new Car
            {
                Id = 4,
                Brand = "Honda",
                Model = "Civic",
                ImageUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1a/Honda_Civic_e-HEV_Sport_%28XI%29_%E2%80%93_f_30062024.jpg/1200px-Honda_Civic_e-HEV_Sport_%28XI%29_%E2%80%93_f_30062024.jpg",
                RentalPricePerDay = 55,
                PurchasePrice = 18000,
                IsForRent = true,
                IsForSale = true
            },
            new Car
            {
                Id = 5,
                Brand = "Mercedes",
                Model = "C-Class",
                ImageUrl = "https://www.topgear.com/sites/default/files/2021/11/Mercedes_C300D_0000.jpg",
                RentalPricePerDay = 130,
                PurchasePrice = 50000,
                IsForRent = false,
                IsForSale = true
            }
        };

        public IActionResult Index()
        {
            return View(cars);
        }

        [Authorize]
        public IActionResult Rent(int id)
        {
            var car = GetCarById(id);
            if (car == null) return NotFound();
            return View("Rent", car);
        }

        [Authorize]
        public IActionResult Buy(int id)
        {
            var car = GetCarById(id);
            if (car == null) return NotFound();
            return View("Buy", car);
        }

        private Car GetCarById(int id)
        {
            return cars.FirstOrDefault(c => c.Id == id);
        }

        public IActionResult Receipt(int id, bool isRent, DateTime? start, DateTime? end)
        {
            var car = GetCarById(id);
            if (car == null) return NotFound();

            ViewData["IsRent"] = isRent;
            ViewData["StartDate"] = start;
            ViewData["EndDate"] = end;
            ViewData["ReceiptNumber"] = Guid.NewGuid().ToString().ToUpper();

            return View(car);
        }
    }
}
