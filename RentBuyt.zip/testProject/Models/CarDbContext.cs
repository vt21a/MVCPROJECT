﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace testProject.Models
{
    public class CarDbContext : IdentityDbContext<IdentityUser>
    {
        public CarDbContext(DbContextOptions<CarDbContext> options) : base(options) { }

        public DbSet<Car> Cars { get; set; }
        public DbSet<RentalTransaction> RentalTransactions { get; set; }
        public DbSet<RentalPurchase> RentalPurchases { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Set decimal precision for Car entity
            modelBuilder.Entity<Car>(entity =>
            {
                entity.Property(c => c.PurchasePrice).HasColumnType("decimal(18,2)");
                entity.Property(c => c.RentalPricePerDay).HasColumnType("decimal(18,2)");
            });

            // Set decimal precision for RentalTransaction entity
            modelBuilder.Entity<RentalTransaction>(entity =>
            {
                entity.Property(r => r.TotalPrice).HasColumnType("decimal(18,2)");
            });
        }
    }
}
