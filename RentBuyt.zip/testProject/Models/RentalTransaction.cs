﻿namespace testProject.Models
{
    public class RentalTransaction
    {
        public int Id { get; set; }
        public int CarId { get; set; }  // Foreign key to Car
        public Car Car { get; set; }  // Navigation property to the Car model
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public bool IsRent { get; set; }  // True for rental, false for purchase
        public decimal TotalPrice { get; set; }
        public string ReceiptNumber { get; set; }
    }
}
