﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using System.IO;
using testProject.Models;

namespace testProject
{
    public class CarDbContextFactory : IDesignTimeDbContextFactory<CarDbContext>
    {
        public CarDbContext CreateDbContext(string[] args)
        {
            // Create a configuration object
            var optionsBuilder = new DbContextOptionsBuilder<CarDbContext>();

            // Build the connection string from appsettings.json
            var configuration = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory()) // Ensure correct path
                .AddJsonFile("appsettings.json") // Make sure it uses the appsettings.json
                .Build();

            var connectionString = configuration.GetConnectionString("CarDbContext");

            // Set up the options for the DbContext
            optionsBuilder.UseSqlServer(connectionString);

            return new CarDbContext(optionsBuilder.Options);
        }
    }
}
